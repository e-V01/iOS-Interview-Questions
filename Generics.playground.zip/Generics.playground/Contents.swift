import UIKit

func determineHigherValue<T: Comparable>(valueOne: T, valueTwo: T) {
    let higherValue = valueOne > valueTwo ? valueOne : valueTwo
    print("\(higherValue) is the higher value")
}

determineHigherValue(valueOne: "Sean", valueTwo: "Swift") // alphabetize order
determineHigherValue(valueOne: 8, valueTwo: 3)
determineHigherValue(valueOne: 3, valueTwo: 8)
determineHigherValue(valueOne: Date.now, valueTwo: Date.distantFuture)
// determineHigherValue(valueOne: "sean", valueTwo: Date.distantPast) //has to be of the same TYPE: String, double, int

var numbersArray = Array(repeating: 3, count: 10)
var stringArray = Array(repeating: "Sean", count: 5)

numbersArray.append(4)
stringArray.append("Swift")
