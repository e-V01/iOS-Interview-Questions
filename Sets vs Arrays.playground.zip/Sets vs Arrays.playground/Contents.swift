import UIKit

// Array are always in the same order, may contain duplicates, less performant(has to check every item in event)
// Set - no duplicates (one of each item), unorder, best performance


var swiftUIDevs: Set = ["Sean", "James"]
var swiftDevs: Set = ["Sean", "James", "Olivia", "Maya", "Leo"]
var kotlinDevs: Set = ["Olivia", "Elijah", "Maya", "Dan"]
var experiencedDevs: Set = ["Sean",  "Ava", "Olivia", "Leo", "Maya"]


// Intersect - pull out overlap
let experiencedSwiftUIDevs = swiftUIDevs.intersection(experiencedDevs)


// Subtract - pull out difference
let juniorSwiftDev = swiftDevs.subtracting(experiencedDevs)


// Disjoint - check for overlap
swiftUIDevs.isDisjoint(with: kotlinDevs)
swiftUIDevs.isDisjoint(with: swiftDevs)


// Union - combine

swiftUIDevs.union(swiftDevs)

// Exclusive - only in 1 set

let pro = swiftDevs.symmetricDifference(kotlinDevs)

// Subset

swiftUIDevs.isSubset(of: swiftDevs)
swiftUIDevs.isSubset(of: kotlinDevs)


// Superset

swiftDevs.isSuperset(of: swiftUIDevs)


//Insert, Delete, Find
swiftDevs.insert("Joe")
swiftDevs.remove("Sean")
swiftDevs.contains("Maya")
swiftDevs
