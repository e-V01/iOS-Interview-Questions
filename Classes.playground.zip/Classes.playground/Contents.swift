import UIKit


class Contact {
    var firstName: String = ""
    var lastName: String = ""
    var phoneNumber: String = ""


    func call() { // method
        print("Calling...")
    }
    init(first: String, last: String, phone: String) {
        firstName = first
        lastName = last
        phoneNumber = phone
    }
}
class Student: Contact {
    var group: String = ""
    var faculty: String = ""
    
}

var object2 = Student(first: "Billy", last: "Bob", phone: "+4499000213123")
object2.group
object2.faculty
var object1 = Contact(first: "Ian", last: "Gub", phone: "+44128643123")


object1.firstName
object1.lastName
object1.phoneNumber

