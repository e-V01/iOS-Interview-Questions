import UIKit

// Unit tests - testing small piece of code to ensure it gives us expected outcome

// Regression - piece of code that was working and then it is broken


