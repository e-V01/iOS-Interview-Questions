import UIKit

//Closures - are self-contained blocks of functionality that can be passed around and used in your code. In simple words they are sort of func that be turn around
// Use @escaping when the closures need to outlive the life of the function that called it
struct Student {
    let name: String
    var testScore: Int
}

let students = [Student(name: "Luke", testScore: 88),
                Student(name: "Dan", testScore: 95),
                Student(name: "Ben", testScore: 79),
                Student(name: "Ian", testScore: 71),
                Student(name: "Paul", testScore: 65),
                Student(name: "Sean", testScore: 61),
]

var topStudentFilter: (Student) -> Bool = { student in
    return student.testScore > 77
}

func topStudentFilterF(student: Student) -> Bool {
    return student.testScore > 80
}

let topStudents = students.filter { $0.testScore > 75 }
let studentRanking = topStudents.sorted { $0.testScore > $1.testScore }

for topStudent in topStudents {
    print(topStudent.name)
}
