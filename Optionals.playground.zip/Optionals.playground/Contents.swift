import UIKit

// Unwrapping Optionals


struct User {
    let name: String
    let age: Int?
}

let user = User(name: "Sean", age: nil)  // remember to change age to NIL or real number like 100



// if let


//if let age = user.age {
//    print("user`s age is \(age)")
//} else {
//    print("User didn`t enter an age")
//}
    
    
// guard let - early exit from method (func)


func check(age: Int?) {
    guard let age = age else {
        print("Age is nil")
        return
        
    }
    
    if age > 40 {
        print("You are old")
    }
}
check(age: user.age)

// nil coalescing

let age = user.age ?? 0
let name = user.name ?? "Uknown"
//print(age)



// force unwrap  (in that case it shows fatal error to force unwrap)

//let age = user.age!
//print(age)

// optional chaining (User struct has to be w/o optional values)

var optionalUser: User?
let name = optionalUser?.name ?? "Not given"


if let newName = optionalUser?.name {
    print(newName)
}
